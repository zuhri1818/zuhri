import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
@st.cache
def load_data():
    data = pd.read_csv('dashboard/ecommerce_data.csv')
    return data
data = load_data()
st.title("E-Commerce Analysis Dashboard")
st.write("""
    Dashboard ini menampilkan analisis data transaksi e-commerce.
    Anda dapat mengeksplorasi berbagai visualisasi terkait transaksi, produk, dan pelanggan.
""")
if st.checkbox('Tampilkan Data'):
    st.write(data)
st.header("Jumlah Transaksi per Kategori Produk")
category_counts = data['Product_Category'].value_counts()
st.bar_chart(category_counts)
st.header("Jumlah Transaksi per Lokasi")
location_counts = data['Location'].value_counts()
st.bar_chart(location_counts)
st.header("Total Pendapatan per Kategori Produk")
data['Total_Spend'] = data['Quantity'] * data['Price']
category_revenue = data.groupby('Product_Category')['Total_Spend'].sum()
st.bar_chart(category_revenue)
if st.checkbox('Tampilkan Statistik Deskriptif'):
    st.write(data.describe())
st.header("Pilih Produk untuk Melihat Detail")
product_options = data['Product_ID'].unique()
selected_product = st.selectbox("Pilih Produk", product_options)
product_data = data[data['Product_ID'] == selected_product]
st.write(f"Detail untuk produk {selected_product}:")
st.write(product_data)

